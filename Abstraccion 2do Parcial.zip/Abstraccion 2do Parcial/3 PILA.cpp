#include <iostream>
using namespace std;

#define MAX 10

// Interfaz
class IPila {
public:
    virtual void push(int valor) = 0;
    virtual int pop() = 0;
    virtual int peek() = 0;
    virtual bool estaVacia() = 0;
    virtual bool estaLlena() = 0;
};

// Clase Abstracta
class PilaAbstracta : public IPila {
protected:
    int top;
    int arr[MAX];

public:
    PilaAbstracta() {
        top = -1;
    }

    bool estaVacia() {
        return top == -1;
    }

    bool estaLlena() {
        return top == MAX - 1;
    }
};

// Implementacion
class Pila : public PilaAbstracta {
public:
    void push(int valor) {
        if (estaLlena()) {
            cout << "Pila llena\n";
            return;
        }
        arr[++top] = valor;
    }

    int pop() {
        if (estaVacia()) {
            cout << "Pila vacia\n";
            return -1;
        }
        return arr[top--];
    }

    int peek() {
        if (estaVacia()) {
            cout << "Pila vacia\n";
            return -1;
        }
        return arr[top];
    }

    void mostrar() {
        for (int i = 0; i <= top; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }

    // Burbuja
    void burbuja() {
        for (int i = 0; i < top; i++) {
            for (int j = 0; j < top - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // QuickSort
    void quickSort(int inicio, int fin) {
        if (inicio >= fin) return;

        int pivote = arr[fin];
        int i = inicio - 1;

        for (int j = inicio; j < fin; j++) {
            if (arr[j] < pivote) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        int temp = arr[i + 1];
        arr[i + 1] = arr[fin];
        arr[fin] = temp;

        int pi = i + 1;

        quickSort(inicio, pi - 1);
        quickSort(pi + 1, fin);
    }

    // Mergesort
    void merge(int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        int* L = new int[n1];
        int* R = new int[n2];

        for (int i = 0; i < n1; i++)
            L[i] = arr[l + i];
        for (int j = 0; j < n2; j++)
            R[j] = arr[m + 1 + j];

        int i = 0, j = 0, k = l;

        while (i < n1 && j < n2) {
            if (L[i] <= R[j])
                arr[k++] = L[i++];
            else
                arr[k++] = R[j++];
        }

        while (i < n1)
            arr[k++] = L[i++];

        while (j < n2)
            arr[k++] = R[j++];

        delete[] L;
        delete[] R;
    }

    void mergeSort(int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            mergeSort(l, m);
            mergeSort(m + 1, r);
            merge(l, m, r);
        }
    }
};

// Main
int main() {
    Pila p;
    int opcion, valor;

    do {
        cout << "\n1. Push\n2. Pop\n3. Mostrar\n4. Burbuja\n5. QuickSort\n6. MergeSort\n0. Salir\n";
        cin >> opcion;

        switch (opcion) {
        case 1:
            cout << "Valor: ";
            cin >> valor;
            p.push(valor);
            break;

        case 2:
            cout << "Eliminado: " << p.pop() << endl;
            break;

        case 3:
            p.mostrar();
            break;

        case 4:
            p.burbuja();
            cout << "Ordenado con Burbuja\n";
            break;

        case 5:
            p.quickSort(0, p.peek());
            cout << "Ordenado con QuickSort\n";
            break;

        case 6:
            p.mergeSort(0, p.peek());
            cout << "Ordenado con MergeSort\n";
            break;
        }

    } while (opcion != 0);

    return 0;
}
