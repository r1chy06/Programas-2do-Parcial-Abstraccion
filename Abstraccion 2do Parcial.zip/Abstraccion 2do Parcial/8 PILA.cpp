#include <iostream>
#include <stack>
#include <vector>
using namespace std;

// INTERFAZ 
class IPila {
public:
    virtual void push(int valor) = 0;
    virtual int pop() = 0;
    virtual int peek() = 0;
    virtual bool estaVacia() = 0;
};

//CLASE ABSTRACTA
class PilaAbstracta : public IPila {
protected:
    stack<int> pila;

public:
    bool estaVacia() {
        return pila.empty();
    }
};

//IMPLEMENTACI�N
class Pila : public PilaAbstracta {
public:

    void push(int valor) {
        pila.push(valor);
    }

    int pop() {
        if (estaVacia()) {
            cout << "Pila vacia\n";
            return -1;
        }
        int val = pila.top();
        pila.pop();
        return val;
    }

    int peek() {
        if (estaVacia()) {
            cout << "Pila vacia\n";
            return -1;
        }
        return pila.top();
    }

    void mostrar() {
        stack<int> temp = pila;
        while (!temp.empty()) {
            cout << temp.top() << " ";
            temp.pop();
        }
        cout << endl;
    }

    //  CONVERTIR A VECTOR 
    vector<int> toVector() {
        vector<int> v;
        stack<int> temp = pila;

        while (!temp.empty()) {
            v.push_back(temp.top());
            temp.pop();
        }

        return v;
    }

    void fromVector(vector<int> v) {
        while (!pila.empty()) pila.pop();

        for (int i = v.size() - 1; i >= 0; i--) {
            pila.push(v[i]);
        }
    }

    // BURBUJA 
    void burbuja() {
        vector<int> v = toVector();

        for (int i = 0; i < v.size() - 1; i++) {
            for (int j = 0; j < v.size() - i - 1; j++) {
                if (v[j] > v[j + 1]) {
                    int temp = v[j];
                    v[j] = v[j + 1];
                    v[j + 1] = temp;
                }
            }
        }

        fromVector(v);
    }

    // QUICKSORT 
    void quickSort(vector<int>& v, int inicio, int fin) {
        if (inicio >= fin) return;

        int pivote = v[fin];
        int i = inicio - 1;

        for (int j = inicio; j < fin; j++) {
            if (v[j] < pivote) {
                i++;
                swap(v[i], v[j]);
            }
        }

        swap(v[i + 1], v[fin]);
        int pi = i + 1;

        quickSort(v, inicio, pi - 1);
        quickSort(v, pi + 1, fin);
    }

    void ordenarQuickSort() {
        vector<int> v = toVector();
        quickSort(v, 0, v.size() - 1);
        fromVector(v);
    }

    //  MERGESORT 
    void merge(vector<int>& v, int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        vector<int> L(n1), R(n2);

        for (int i = 0; i < n1; i++)
            L[i] = v[l + i];
        for (int j = 0; j < n2; j++)
            R[j] = v[m + 1 + j];

        int i = 0, j = 0, k = l;

        while (i < n1 && j < n2) {
            if (L[i] <= R[j])
                v[k++] = L[i++];
            else
                v[k++] = R[j++];
        }

        while (i < n1)
            v[k++] = L[i++];

        while (j < n2)
            v[k++] = R[j++];
    }

    void mergeSort(vector<int>& v, int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            mergeSort(v, l, m);
            mergeSort(v, m + 1, r);
            merge(v, l, m, r);
        }
    }

    void ordenarMergeSort() {
        vector<int> v = toVector();
        mergeSort(v, 0, v.size() - 1);
        fromVector(v);
    }
};

// MAIN 
int main() {
    Pila p;
    int opcion, valor;

    do {
        cout << "\n1. Push\n2. Pop\n3. Mostrar\n4. Burbuja\n5. QuickSort\n6. MergeSort\n0. Salir\n";
        cin >> opcion;

        switch (opcion) {
        case 1:
            cout << "Valor: ";
            cin >> valor;
            p.push(valor);
            break;

        case 2:
            cout << "Eliminado: " << p.pop() << endl;
            break;

        case 3:
            p.mostrar();
            break;

        case 4:
            p.burbuja();
            cout << "Ordenado con Burbuja\n";
            break;

        case 5:
            p.ordenarQuickSort();
            cout << "Ordenado con QuickSort\n";
            break;

        case 6:
            p.ordenarMergeSort();
            cout << "Ordenado con MergeSort\n";
            break;
        }

    } while (opcion != 0);

    return 0;
}
