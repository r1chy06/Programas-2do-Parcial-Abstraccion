#include <iostream>
#include <stack>
#include <list>
#include <string>
using namespace std;

template <typename T>
class IOrdenador {
public:
    virtual void quickSortIndirecto(T* arr, int n) = 0;
};

template <typename T>
class OrdenadorBase : public IOrdenador<T> {
public:
    void imprimirIndirecto(T* arr, int* idx, int n) {
        for (int i = 0; i < n; i++)
            cout << arr[idx[i]] << " ";
        cout << endl;
    }
};

class Persona {
public:
    string nombre;
    int edad;

    Persona() {}
    Persona(string n, int e) {
        nombre = n;
        edad = e;
    }

    bool operator<(const Persona& other) const {
        return edad < other.edad;
    }

    friend ostream& operator<<(ostream& os, const Persona& p) {
        os << p.nombre << "(" << p.edad << ")";
        return os;
    }
};

template <typename T>
class Ordenador : public OrdenadorBase<T> {
private:
    void swap(int* a, int* b) {
        int temp = *a;
        *a = *b;
        *b = temp;
    }

    int partition(T* arr, int* idx, int low, int high) {
        int pivot = idx[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (arr[idx[j]] < arr[pivot]) {
                i++;
                swap(&idx[i], &idx[j]);
            }
        }

        swap(&idx[i + 1], &idx[high]);
        return i + 1;
    }

public:
    void quickSortIndirecto(T* arr, int n) {
        int* idx = new int[n];
        for (int i = 0; i < n; i++)
            idx[i] = i;

        stack<int> st;
        st.push(0);
        st.push(n - 1);

        while (!st.empty()) {
            int high = st.top(); st.pop();
            int low = st.top(); st.pop();

            int pi = partition(arr, idx, low, high);

            if (pi - 1 > low) {
                st.push(low);
                st.push(pi - 1);
            }

            if (pi + 1 < high) {
                st.push(pi + 1);
                st.push(high);
            }
        }

        this->imprimirIndirecto(arr, idx, n);

        delete[] idx;
    }
};

int main() {
    Ordenador<int> ordInt;
    Ordenador<char> ordChar;
    Ordenador<Persona> ordPersona;

    int* arrInt = new int[5];
    arrInt[0]=5; arrInt[1]=2; arrInt[2]=9; arrInt[3]=1; arrInt[4]=3;

    ordInt.quickSortIndirecto(arrInt, 5);

    char arrChar[5] = {'z','a','k','b','m'};
    ordChar.quickSortIndirecto(arrChar, 5);

    Persona arrP[4];
    arrP[0]=Persona("Juan",25);
    arrP[1]=Persona("Ana",20);
    arrP[2]=Persona("Luis",30);
    arrP[3]=Persona("Pedro",18);

    ordPersona.quickSortIndirecto(arrP, 4);

    list<int> lista;
    lista.push_back(4);
    lista.push_back(1);
    lista.push_back(7);
    lista.push_back(2);

    for (list<int>::iterator it = lista.begin(); it != lista.end(); ++it)
        cout << *it << " ";
    cout << endl;

    stack<int> pila;
    pila.push(10);
    pila.push(20);
    pila.push(30);

    while (!pila.empty()) {
        cout << pila.top() << " ";
        pila.pop();
    }
    cout << endl;

    delete[] arrInt;
    return 0;
}
