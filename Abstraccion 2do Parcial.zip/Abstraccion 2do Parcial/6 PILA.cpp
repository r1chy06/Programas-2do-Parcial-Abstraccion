#include <iostream>
using namespace std;

//  NODO
struct Nodo {
    int dato;
    Nodo* siguiente;
};

// INTERFAZ 
class IPila {
public:
    virtual void push(int valor) = 0;
    virtual int pop() = 0;
    virtual int peek() = 0;
    virtual bool estaVacia() = 0;
};

// CLASE ABSTRACTA 
class PilaAbstracta : public IPila {
protected:
    Nodo* top;

public:
    PilaAbstracta() {
        top = NULL;
    }

    bool estaVacia() {
        return top == NULL;
    }
};

// IMPLEMENTACI�N 
class Pila : public PilaAbstracta {
public:

    void push(int valor) {
        Nodo* nuevo = new Nodo();
        nuevo->dato = valor;
        nuevo->siguiente = top;
        top = nuevo;
    }

    int pop() {
        if (estaVacia()) {
            cout << "Pila vacia\n";
            return -1;
        }

        Nodo* temp = top;
        int valor = temp->dato;
        top = top->siguiente;
        delete temp;

        return valor;
    }

    int peek() {
        if (estaVacia()) {
            cout << "Pila vacia\n";
            return -1;
        }
        return top->dato;
    }

    void mostrar() {
        Nodo* aux = top;
        while (aux != NULL) {
            cout << aux->dato << " ";
            aux = aux->siguiente;
        }
        cout << endl;
    }

    // CONVERTIR A ARREGLO
    int* toArray(int& n) {
        n = 0;
        Nodo* aux = top;

        while (aux != NULL) {
            n++;
            aux = aux->siguiente;
        }

        int* arr = new int[n];
        aux = top;

        for (int i = 0; i < n; i++) {
            arr[i] = aux->dato;
            aux = aux->siguiente;
        }

        return arr;
    }

    void fromArray(int arr[], int n) {
        while (!estaVacia()) pop();
        for (int i = n - 1; i >= 0; i--) {
            push(arr[i]);
        }
    }

    // BURBUJA 
    void burbuja() {
        int n;
        int* arr = toArray(n);

        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }

        fromArray(arr, n);
        delete[] arr;
    }

    // QUICKSORT 
    void quickSort(int arr[], int inicio, int fin) {
        if (inicio >= fin) return;

        int pivote = arr[fin];
        int i = inicio - 1;

        for (int j = inicio; j < fin; j++) {
            if (arr[j] < pivote) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        int temp = arr[i + 1];
        arr[i + 1] = arr[fin];
        arr[fin] = temp;

        int pi = i + 1;

        quickSort(arr, inicio, pi - 1);
        quickSort(arr, pi + 1, fin);
    }

    void ordenarQuickSort() {
        int n;
        int* arr = toArray(n);

        quickSort(arr, 0, n - 1);

        fromArray(arr, n);
        delete[] arr;
    }

    // MERGESORT
    void merge(int arr[], int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        int* L = new int[n1];
        int* R = new int[n2];

        for (int i = 0; i < n1; i++)
            L[i] = arr[l + i];
        for (int j = 0; j < n2; j++)
            R[j] = arr[m + 1 + j];

        int i = 0, j = 0, k = l;

        while (i < n1 && j < n2) {
            if (L[i] <= R[j])
                arr[k++] = L[i++];
            else
                arr[k++] = R[j++];
        }

        while (i < n1)
            arr[k++] = L[i++];

        while (j < n2)
            arr[k++] = R[j++];

        delete[] L;
        delete[] R;
    }

    void mergeSort(int arr[], int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            mergeSort(arr, l, m);
            mergeSort(arr, m + 1, r);
            merge(arr, l, m, r);
        }
    }

    void ordenarMergeSort() {
        int n;
        int* arr = toArray(n);

        mergeSort(arr, 0, n - 1);

        fromArray(arr, n);
        delete[] arr;
    }
};

// MAIN
int main() {
    Pila p;
    int opcion, valor;

    do {
        cout << "\n1. Push\n2. Pop\n3. Mostrar\n4. Burbuja\n5. QuickSort\n6. MergeSort\n0. Salir\n";
        cin >> opcion;

        switch (opcion) {
        case 1:
            cout << "Valor: ";
            cin >> valor;
            p.push(valor);
            break;

        case 2:
            cout << "Eliminado: " << p.pop() << endl;
            break;

        case 3:
            p.mostrar();
            break;

        case 4:
            p.burbuja();
            cout << "Ordenado con Burbuja\n";
            break;

        case 5:
            p.ordenarQuickSort();
            cout << "Ordenado con QuickSort\n";
            break;

        case 6:
            p.ordenarMergeSort();
            cout << "Ordenado con MergeSort\n";
            break;
        }

    } while (opcion != 0);

    return 0;
}
