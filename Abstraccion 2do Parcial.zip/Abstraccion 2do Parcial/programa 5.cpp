#include <iostream>
#include <stack>
#include <list>
#include <string>
using namespace std;

template <typename T>
class IOrdenador {
public:
    virtual void mergeSortIndirecto(T* arr, int n) = 0;
};

template <typename T>
class OrdenadorBase : public IOrdenador<T> {
public:
    void imprimirIndirecto(T* arr, int* idx, int n) {
        for (int i = 0; i < n; i++)
            cout << arr[idx[i]] << " ";
        cout << endl;
    }
};

class Persona {
public:
    string nombre;
    int edad;

    Persona() {}
    Persona(string n, int e) {
        nombre = n;
        edad = e;
    }

    bool operator<(const Persona& other) const {
        return edad < other.edad;
    }

    friend ostream& operator<<(ostream& os, const Persona& p) {
        os << p.nombre << "(" << p.edad << ")";
        return os;
    }
};

template <typename T>
class Ordenador : public OrdenadorBase<T> {
private:
    void merge(T* arr, int* idx, int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        int* L = new int[n1];
        int* R = new int[n2];

        int i,j,k;

        for (i = 0; i < n1; i++)
            L[i] = idx[l + i];

        for (j = 0; j < n2; j++)
            R[j] = idx[m + 1 + j];

        i = 0; j = 0; k = l;

        while (i < n1 && j < n2) {
            if (arr[L[i]] < arr[R[j]])
                idx[k++] = L[i++];
            else
                idx[k++] = R[j++];
        }

        while (i < n1)
            idx[k++] = L[i++];

        while (j < n2)
            idx[k++] = R[j++];

        delete[] L;
        delete[] R;
    }

public:
    void mergeSortIndirecto(T* arr, int n) {
        int* idx = new int[n];
        int i;

        for (i = 0; i < n; i++)
            idx[i] = i;

        int curr, left, mid, right;

        for (curr = 1; curr <= n - 1; curr = curr * 2) {
            for (left = 0; left < n - 1; left += 2 * curr) {
                mid = left + curr - 1;
                if (mid >= n - 1) mid = n - 1;

                right = left + 2 * curr - 1;
                if (right >= n - 1) right = n - 1;

                merge(arr, idx, left, mid, right);
            }
        }

        this->imprimirIndirecto(arr, idx, n);

        delete[] idx;
    }
};

int main() {
    Ordenador<int> ordInt;
    Ordenador<char> ordChar;
    Ordenador<Persona> ordPersona;

    int* arrInt = new int[5];
    arrInt[0]=5; arrInt[1]=2; arrInt[2]=9; arrInt[3]=1; arrInt[4]=3;

    ordInt.mergeSortIndirecto(arrInt, 5);

    char arrChar[5] = {'z','a','k','b','m'};
    ordChar.mergeSortIndirecto(arrChar, 5);

    Persona arrP[4];
    arrP[0]=Persona("Juan",25);
    arrP[1]=Persona("Ana",20);
    arrP[2]=Persona("Luis",30);
    arrP[3]=Persona("Pedro",18);

    ordPersona.mergeSortIndirecto(arrP, 4);

    list<int> lista;
    lista.push_back(4);
    lista.push_back(1);
    lista.push_back(7);
    lista.push_back(2);

    for (list<int>::iterator it = lista.begin(); it != lista.end(); ++it)
        cout << *it << " ";
    cout << endl;

    stack<int> pila;
    pila.push(10);
    pila.push(20);
    pila.push(30);

    while (!pila.empty()) {
        cout << pila.top() << " ";
        pila.pop();
    }
    cout << endl;

    delete[] arrInt;
    return 0;
}
