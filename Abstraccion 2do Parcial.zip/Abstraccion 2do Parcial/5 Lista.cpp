#include <iostream>
using namespace std;

#define MAX 10

// INTERFAZ 
class ILista {
public:
    virtual void insertar(int valor) = 0;
    virtual void eliminar(int valor) = 0;
    virtual int buscar(int valor) = 0;
    virtual bool estaLlena() = 0;
    virtual bool estaVacia() = 0;
};

// CLASE ABSTRACTA 
class ListaAbstracta : public ILista {
protected:
    int arr[MAX];
    int size;

public:
    ListaAbstracta() {
        size = 0;
    }

    bool estaLlena() {
        return size == MAX;
    }

    bool estaVacia() {
        return size == 0;
    }
};

// IMPLEMENTACI�N
class Lista : public ListaAbstracta {
public:

    void insertar(int valor) {
        if (estaLlena()) {
            cout << "Lista llena\n";
            return;
        }
        arr[size++] = valor;
    }

    void eliminar(int valor) {
        if (estaVacia()) {
            cout << "Lista vacia\n";
            return;
        }

        int pos = buscar(valor);

        if (pos == -1) {
            cout << "Valor no encontrado\n";
            return;
        }

        for (int i = pos; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }
        size--;
    }

    int buscar(int valor) {
        for (int i = 0; i < size; i++) {
            if (arr[i] == valor)
                return i;
        }
        return -1;
    }

    void mostrar() {
        for (int i = 0; i < size; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }

    int getSize() {
        return size;
    }

    // BURBUJA
    void burbuja() {
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // QUICKSORT
    void quickSort(int inicio, int fin) {
        if (inicio >= fin) return;

        int pivote = arr[fin];
        int i = inicio - 1;

        for (int j = inicio; j < fin; j++) {
            if (arr[j] < pivote) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        int temp = arr[i + 1];
        arr[i + 1] = arr[fin];
        arr[fin] = temp;

        int pi = i + 1;

        quickSort(inicio, pi - 1);
        quickSort(pi + 1, fin);
    }

    // MERGESORT 
    void merge(int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        int* L = new int[n1];
        int* R = new int[n2];

        for (int i = 0; i < n1; i++)
            L[i] = arr[l + i];
        for (int j = 0; j < n2; j++)
            R[j] = arr[m + 1 + j];

        int i = 0, j = 0, k = l;

        while (i < n1 && j < n2) {
            if (L[i] <= R[j])
                arr[k++] = L[i++];
            else
                arr[k++] = R[j++];
        }

        while (i < n1)
            arr[k++] = L[i++];

        while (j < n2)
            arr[k++] = R[j++];

        delete[] L;
        delete[] R;
    }

    void mergeSort(int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            mergeSort(l, m);
            mergeSort(m + 1, r);
            merge(l, m, r);
        }
    }
};

// MAIN
int main() {
    Lista lista;
    int opcion, valor;

    do {
        cout << "\n1. Insertar\n2. Eliminar\n3. Buscar\n4. Mostrar\n5. Burbuja\n6. QuickSort\n7. MergeSort\n0. Salir\n";
        cin >> opcion;

        switch (opcion) {
        case 1:
            cout << "Valor: ";
            cin >> valor;
            lista.insertar(valor);
            break;

        case 2:
            cout << "Valor a eliminar: ";
            cin >> valor;
            lista.eliminar(valor);
            break;

        case 3:
            cout << "Valor a buscar: ";
            cin >> valor;
            cout << "Posicion: " << lista.buscar(valor) << endl;
            break;

        case 4:
            lista.mostrar();
            break;

        case 5:
            lista.burbuja();
            cout << "Ordenado con Burbuja\n";
            break;

        case 6:
            lista.quickSort(0, lista.getSize() - 1);
            cout << "Ordenado con QuickSort\n";
            break;

        case 7:
            lista.mergeSort(0, lista.getSize() - 1);
            cout << "Ordenado con MergeSort\n";
            break;
        }

    } while (opcion != 0);

    return 0;
}
