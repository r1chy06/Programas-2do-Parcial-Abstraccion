#include <iostream>
using namespace std;

#define MAX 10

// INTERFAZ
class ICola {
public:
    virtual void enqueue(int valor) = 0;
    virtual int dequeue() = 0;
    virtual int frontElemento() = 0;
    virtual bool estaVacia() = 0;
    virtual bool estaLlena() = 0;
};

// CLASE ABSTRACTA 
class ColaAbstracta : public ICola {
protected:
    int frente;
    int final;
    int arr[MAX];

public:
    ColaAbstracta() {
        frente = 0;
        final = -1;
    }

    bool estaVacia() {
        return final < frente;
    }

    bool estaLlena() {
        return final == MAX - 1;
    }
};

// IMPLEMENTACI�N 
class Cola : public ColaAbstracta {
public:
    void enqueue(int valor) {
        if (estaLlena()) {
            cout << "Cola llena\n";
            return;
        }
        arr[++final] = valor;
    }

    int dequeue() {
        if (estaVacia()) {
            cout << "Cola vacia\n";
            return -1;
        }
        return arr[frente++];
    }

    int frontElemento() {
        if (estaVacia()) {
            cout << "Cola vacia\n";
            return -1;
        }
        return arr[frente];
    }

    void mostrar() {
        for (int i = frente; i <= final; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }

    int getInicio() {
        return frente;
    }

    int getFinal() {
        return final;
    }

    // BURBUJA 
    void burbuja() {
        for (int i = frente; i < final; i++) {
            for (int j = frente; j < final - (i - frente); j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // QUICKSORT 
    void quickSort(int inicio, int fin) {
        if (inicio >= fin) return;

        int pivote = arr[fin];
        int i = inicio - 1;

        for (int j = inicio; j < fin; j++) {
            if (arr[j] < pivote) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        int temp = arr[i + 1];
        arr[i + 1] = arr[fin];
        arr[fin] = temp;

        int pi = i + 1;

        quickSort(inicio, pi - 1);
        quickSort(pi + 1, fin);
    }

    // MERGESORT 
    void merge(int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        int* L = new int[n1];
        int* R = new int[n2];

        for (int i = 0; i < n1; i++)
            L[i] = arr[l + i];
        for (int j = 0; j < n2; j++)
            R[j] = arr[m + 1 + j];

        int i = 0, j = 0, k = l;

        while (i < n1 && j < n2) {
            if (L[i] <= R[j])
                arr[k++] = L[i++];
            else
                arr[k++] = R[j++];
        }

        while (i < n1)
            arr[k++] = L[i++];

        while (j < n2)
            arr[k++] = R[j++];

        delete[] L;
        delete[] R;
    }

    void mergeSort(int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            mergeSort(l, m);
            mergeSort(m + 1, r);
            merge(l, m, r);
        }
    }
};

// MAIN
int main() {
    Cola c;
    int opcion, valor;

    do {
        cout << "\n1. Enqueue\n2. Dequeue\n3. Mostrar\n4. Burbuja\n5. QuickSort\n6. MergeSort\n0. Salir\n";
        cin >> opcion;

        switch (opcion) {
        case 1:
            cout << "Valor: ";
            cin >> valor;
            c.enqueue(valor);
            break;

        case 2:
            cout << "Eliminado: " << c.dequeue() << endl;
            break;

        case 3:
            c.mostrar();
            break;

        case 4:
            c.burbuja();
            cout << "Ordenado con Burbuja\n";
            break;

        case 5:
            c.quickSort(c.getInicio(), c.getFinal());
            cout << "Ordenado con QuickSort\n";
            break;

        case 6:
            c.mergeSort(c.getInicio(), c.getFinal());
            cout << "Ordenado con MergeSort\n";
            break;
        }

    } while (opcion != 0);

    return 0;
}
