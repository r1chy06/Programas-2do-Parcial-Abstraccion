#include <iostream>
#include <list>
#include <vector>
using namespace std;

// INTERFAZ 
class ILista {
public:
    virtual void insertar(int valor) = 0;
    virtual void eliminar(int valor) = 0;
    virtual int buscar(int valor) = 0;
    virtual bool estaVacia() = 0;
};

// CLASE ABSTRACTA 
class ListaAbstracta : public ILista {
protected:
    list<int> lista;

public:
    bool estaVacia() {
        return lista.empty();
    }
};

// IMPLEMENTACI�N 
class Lista : public ListaAbstracta {
public:

    void insertar(int valor) {
        lista.push_back(valor);
    }

    void eliminar(int valor) {
        for (auto it = lista.begin(); it != lista.end(); ++it) {
            if (*it == valor) {
                lista.erase(it);
                return;
            }
        }
        cout << "Valor no encontrado\n";
    }

    int buscar(int valor) {
        int pos = 0;
        for (auto it = lista.begin(); it != lista.end(); ++it) {
            if (*it == valor)
                return pos;
            pos++;
        }
        return -1;
    }

    void mostrar() {
        for (auto x : lista) {
            cout << x << " ";
        }
        cout << endl;
    }

    // CONVERTIR A VECTOR 
    vector<int> toVector() {
        vector<int> v;
        for (auto x : lista) {
            v.push_back(x);
        }
        return v;
    }

    void fromVector(vector<int> v) {
        lista.clear();
        for (int i = 0; i < v.size(); i++) {
            lista.push_back(v[i]);
        }
    }

    // BURBUJA 
    void burbuja() {
        vector<int> v = toVector();

        for (int i = 0; i < v.size() - 1; i++) {
            for (int j = 0; j < v.size() - i - 1; j++) {
                if (v[j] > v[j + 1]) {
                    int temp = v[j];
                    v[j] = v[j + 1];
                    v[j + 1] = temp;
                }
            }
        }

        fromVector(v);
    }

    // QUICKSORT 
    void quickSort(vector<int>& v, int inicio, int fin) {
        if (inicio >= fin) return;

        int pivote = v[fin];
        int i = inicio - 1;

        for (int j = inicio; j < fin; j++) {
            if (v[j] < pivote) {
                i++;
                swap(v[i], v[j]);
            }
        }

        swap(v[i + 1], v[fin]);
        int pi = i + 1;

        quickSort(v, inicio, pi - 1);
        quickSort(v, pi + 1, fin);
    }

    void ordenarQuickSort() {
        vector<int> v = toVector();
        quickSort(v, 0, v.size() - 1);
        fromVector(v);
    }

    // MERGESORT
    void merge(vector<int>& v, int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        vector<int> L(n1), R(n2);

        for (int i = 0; i < n1; i++)
            L[i] = v[l + i];
        for (int j = 0; j < n2; j++)
            R[j] = v[m + 1 + j];

        int i = 0, j = 0, k = l;

        while (i < n1 && j < n2) {
            if (L[i] <= R[j])
                v[k++] = L[i++];
            else
                v[k++] = R[j++];
        }

        while (i < n1)
            v[k++] = L[i++];

        while (j < n2)
            v[k++] = R[j++];
    }

    void mergeSort(vector<int>& v, int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            mergeSort(v, l, m);
            mergeSort(v, m + 1, r);
            merge(v, l, m, r);
        }
    }

    void ordenarMergeSort() {
        vector<int> v = toVector();
        mergeSort(v, 0, v.size() - 1);
        fromVector(v);
    }
};

// MAIN 
int main() {
    Lista lista;
    int opcion, valor;

    do {
        cout << "\n1. Insertar\n2. Eliminar\n3. Buscar\n4. Mostrar\n5. Burbuja\n6. QuickSort\n7. MergeSort\n0. Salir\n";
        cin >> opcion;

        switch (opcion) {
        case 1:
            cout << "Valor: ";
            cin >> valor;
            lista.insertar(valor);
            break;

        case 2:
            cout << "Valor a eliminar: ";
            cin >> valor;
            lista.eliminar(valor);
            break;

        case 3:
            cout << "Valor a buscar: ";
            cin >> valor;
            cout << "Posicion: " << lista.buscar(valor) << endl;
            break;

        case 4:
            lista.mostrar();
            break;

        case 5:
            lista.burbuja();
            cout << "Ordenado con Burbuja\n";
            break;

        case 6:
            lista.ordenarQuickSort();
            cout << "Ordenado con QuickSort\n";
            break;

        case 7:
            lista.ordenarMergeSort();
            cout << "Ordenado con MergeSort\n";
            break;
        }

    } while (opcion != 0);

    return 0;
}
