#include <iostream>
#include <stack>
#include <list>
#include <string>
using namespace std;

template <typename T>
class IOrdenador {
public:
    virtual void mergeSort(T* arr, int n) = 0;
};

template <typename T>
class OrdenadorBase : public IOrdenador<T> {
public:
    void imprimir(T* arr, int n) {
        for (int i = 0; i < n; i++)
            cout << arr[i] << " ";
        cout << endl;
    }
};

class Persona {
public:
    string nombre;
    int edad;

    Persona() {}
    Persona(string n, int e) {
        nombre = n;
        edad = e;
    }

    bool operator<(const Persona& other) const {
        return edad < other.edad;
    }

    friend ostream& operator<<(ostream& os, const Persona& p) {
        os << p.nombre << "(" << p.edad << ")";
        return os;
    }
};

template <typename T>
class Ordenador : public OrdenadorBase<T> {
private:
    void merge(T* arr, int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        T* L = new T[n1];
        T* R = new T[n2];

        int i, j, k;

        for (i = 0; i < n1; i++)
            L[i] = arr[l + i];

        for (j = 0; j < n2; j++)
            R[j] = arr[m + 1 + j];

        i = 0; j = 0; k = l;

        while (i < n1 && j < n2) {
            if (L[i] < R[j])
                arr[k++] = L[i++];
            else
                arr[k++] = R[j++];
        }

        while (i < n1)
            arr[k++] = L[i++];

        while (j < n2)
            arr[k++] = R[j++];

        delete[] L;
        delete[] R;
    }

public:
    void mergeSort(T* arr, int n) {
        int curr, left, mid, right;

        for (curr = 1; curr <= n - 1; curr = curr * 2) {
            for (left = 0; left < n - 1; left += 2 * curr) {
                mid = left + curr - 1;
                if (mid >= n - 1) mid = n - 1;

                right = left + 2 * curr - 1;
                if (right >= n - 1) right = n - 1;

                merge(arr, left, mid, right);
            }
        }
    }
};

int main() {
    Ordenador<int> ordInt;
    Ordenador<char> ordChar;
    Ordenador<Persona> ordPersona;

    int* arrInt = new int[5];
    arrInt[0]=5; arrInt[1]=2; arrInt[2]=9; arrInt[3]=1; arrInt[4]=3;

    ordInt.mergeSort(arrInt, 5);
    ordInt.imprimir(arrInt, 5);

    char arrChar[5] = {'z','a','k','b','m'};
    ordChar.mergeSort(arrChar, 5);
    ordChar.imprimir(arrChar, 5);

    Persona arrP[4];
    arrP[0]=Persona("Juan",25);
    arrP[1]=Persona("Ana",20);
    arrP[2]=Persona("Luis",30);
    arrP[3]=Persona("Pedro",18);

    ordPersona.mergeSort(arrP, 4);
    ordPersona.imprimir(arrP, 4);

    list<int> lista;
    lista.push_back(4);
    lista.push_back(1);
    lista.push_back(7);
    lista.push_back(2);

    for (list<int>::iterator it = lista.begin(); it != lista.end(); ++it)
        cout << *it << " ";
    cout << endl;

    stack<int> pila;
    pila.push(10);
    pila.push(20);
    pila.push(30);

    while (!pila.empty()) {
        cout << pila.top() << " ";
        pila.pop();
    }
    cout << endl;

    delete[] arrInt;
    return 0;
}
