#include <iostream>
using namespace std;

//NODO
struct Nodo {
    int dato;
    Nodo* siguiente;
};

// INTERFAZ
class ILista {
public:
    virtual void insertar(int valor) = 0;
    virtual void eliminar(int valor) = 0;
    virtual int buscar(int valor) = 0;
    virtual bool estaVacia() = 0;
};

//CLASE ABSTRACTA 
class ListaAbstracta : public ILista {
protected:
    Nodo* cabeza;

public:
    ListaAbstracta() {
        cabeza = NULL;
    }

    bool estaVacia() {
        return cabeza == NULL;
    }
};

//IMPLEMENTACI�N
class Lista : public ListaAbstracta {
public:

    void insertar(int valor) {
        Nodo* nuevo = new Nodo();
        nuevo->dato = valor;
        nuevo->siguiente = NULL;

        if (estaVacia()) {
            cabeza = nuevo;
        } else {
            Nodo* aux = cabeza;
            while (aux->siguiente != NULL)
                aux = aux->siguiente;
            aux->siguiente = nuevo;
        }
    }

    void eliminar(int valor) {
        if (estaVacia()) {
            cout << "Lista vacia\n";
            return;
        }

        Nodo* actual = cabeza;
        Nodo* anterior = NULL;

        while (actual != NULL && actual->dato != valor) {
            anterior = actual;
            actual = actual->siguiente;
        }

        if (actual == NULL) {
            cout << "Valor no encontrado\n";
            return;
        }

        if (anterior == NULL) {
            cabeza = actual->siguiente;
        } else {
            anterior->siguiente = actual->siguiente;
        }

        delete actual;
    }

    int buscar(int valor) {
        Nodo* aux = cabeza;
        int pos = 0;

        while (aux != NULL) {
            if (aux->dato == valor)
                return pos;
            aux = aux->siguiente;
            pos++;
        }
        return -1;
    }

    void mostrar() {
        Nodo* aux = cabeza;
        while (aux != NULL) {
            cout << aux->dato << " ";
            aux = aux->siguiente;
        }
        cout << endl;
    }

    // CONVERTIR A ARREGLO
    int* toArray(int& n) {
        n = 0;
        Nodo* aux = cabeza;

        while (aux != NULL) {
            n++;
            aux = aux->siguiente;
        }

        int* arr = new int[n];
        aux = cabeza;

        for (int i = 0; i < n; i++) {
            arr[i] = aux->dato;
            aux = aux->siguiente;
        }

        return arr;
    }

    void fromArray(int arr[], int n) {
        // limpiar la lista
        while (!estaVacia()) {
            eliminar(cabeza->dato);
        }

        for (int i = 0; i < n; i++) {
            insertar(arr[i]);
        }
    }

    // BURBUJA 
    void burbuja() {
        int n;
        int* arr = toArray(n);

        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }

        fromArray(arr, n);
        delete[] arr;
    }

    // QUICKSORT 
    void quickSort(int arr[], int inicio, int fin) {
        if (inicio >= fin) return;

        int pivote = arr[fin];
        int i = inicio - 1;

        for (int j = inicio; j < fin; j++) {
            if (arr[j] < pivote) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        int temp = arr[i + 1];
        arr[i + 1] = arr[fin];
        arr[fin] = temp;

        int pi = i + 1;

        quickSort(arr, inicio, pi - 1);
        quickSort(arr, pi + 1, fin);
    }

    void ordenarQuickSort() {
        int n;
        int* arr = toArray(n);

        quickSort(arr, 0, n - 1);

        fromArray(arr, n);
        delete[] arr;
    }

    // MERGESORT
    void merge(int arr[], int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        int* L = new int[n1];
        int* R = new int[n2];

        for (int i = 0; i < n1; i++)
            L[i] = arr[l + i];
        for (int j = 0; j < n2; j++)
            R[j] = arr[m + 1 + j];

        int i = 0, j = 0, k = l;

        while (i < n1 && j < n2) {
            if (L[i] <= R[j])
                arr[k++] = L[i++];
            else
                arr[k++] = R[j++];
        }

        while (i < n1)
            arr[k++] = L[i++];

        while (j < n2)
            arr[k++] = R[j++];

        delete[] L;
        delete[] R;
    }

    void mergeSort(int arr[], int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            mergeSort(arr, l, m);
            mergeSort(arr, m + 1, r);
            merge(arr, l, m, r);
        }
    }

    void ordenarMergeSort() {
        int n;
        int* arr = toArray(n);

        mergeSort(arr, 0, n - 1);

        fromArray(arr, n);
        delete[] arr;
    }
};

//  MAIN
int main() {
    Lista lista;
    int opcion, valor;

    do {
        cout << "\n1. Insertar\n2. Eliminar\n3. Buscar\n4. Mostrar\n5. Burbuja\n6. QuickSort\n7. MergeSort\n0. Salir\n";
        cin >> opcion;

        switch (opcion) {
        case 1:
            cout << "Valor: ";
            cin >> valor;
            lista.insertar(valor);
            break;

        case 2:
            cout << "Valor a eliminar: ";
            cin >> valor;
            lista.eliminar(valor);
            break;

        case 3:
            cout << "Valor a buscar: ";
            cin >> valor;
            cout << "Posicion: " << lista.buscar(valor) << endl;
            break;

        case 4:
            lista.mostrar();
            break;

        case 5:
            lista.burbuja();
            cout << "Ordenado con Burbuja\n";
            break;

        case 6:
            lista.ordenarQuickSort();
            cout << "Ordenado con QuickSort\n";
            break;

        case 7:
            lista.ordenarMergeSort();
            cout << "Ordenado con MergeSort\n";
            break;
        }

    } while (opcion != 0);

    return 0;
}
