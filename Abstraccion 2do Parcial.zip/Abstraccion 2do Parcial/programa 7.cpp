#include <iostream>
#include <stack>
#include <list>
#include <string>
using namespace std;

template <typename T>
class Nodo {
public:
    T dato;
    Nodo<T>* sig;

    Nodo() { sig = 0; }
    Nodo(T d) { dato = d; sig = 0; }
};

class Persona {
public:
    string nombre;
    int edad;
    Persona* ref;

    Persona() { ref = 0; }
    Persona(string n, int e) {
        nombre = n;
        edad = e;
        ref = 0;
    }

    bool operator<(const Persona& other) const {
        return edad < other.edad;
    }

    friend ostream& operator<<(ostream& os, const Persona& p) {
        os << p.nombre << "(" << p.edad << ")";
        return os;
    }
};

template <typename T>
class IOrdenador {
public:
    virtual void burbujaIndirecto(T* arr, int n) = 0;
};

template <typename T>
class OrdenadorBase : public IOrdenador<T> {
public:
    void imprimirIndirecto(T* arr, int* idx, int n) {
        for (int i = 0; i < n; i++)
            cout << arr[idx[i]] << " ";
        cout << endl;
    }
};

template <typename T>
class Ordenador : public OrdenadorBase<T> {
private:
    void swap(int* a, int* b) {
        int t = *a;
        *a = *b;
        *b = t;
    }

public:
    void burbujaIndirecto(T* arr, int n) {
        int* idx = new int[n];
        for (int i = 0; i < n; i++)
            idx[i] = i;

        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (arr[idx[j]] < arr[idx[j + 1]] == false)
                    swap(&idx[j], &idx[j + 1]);

        this->imprimirIndirecto(arr, idx, n);
        delete[] idx;
    }
};

int main() {
    Ordenador<int> ordInt;
    Ordenador<char> ordChar;
    Ordenador<Persona> ordPersona;

    int* arrInt = new int[5];
    arrInt[0]=5; arrInt[1]=2; arrInt[2]=9; arrInt[3]=1; arrInt[4]=3;

    ordInt.burbujaIndirecto(arrInt, 5);

    char arrChar[5] = {'z','a','k','b','m'};
    ordChar.burbujaIndirecto(arrChar, 5);

    Persona arrP[4];
    arrP[0]=Persona("Juan",25);
    arrP[1]=Persona("Ana",20);
    arrP[2]=Persona("Luis",30);
    arrP[3]=Persona("Pedro",18);

    arrP[0].ref = &arrP[1];
    arrP[1].ref = &arrP[2];
    arrP[2].ref = &arrP[3];
    arrP[3].ref = &arrP[0];

    ordPersona.burbujaIndirecto(arrP, 4);

    Nodo<int>* lista = new Nodo<int>(4);
    lista->sig = new Nodo<int>(1);
    lista->sig->sig = new Nodo<int>(7);
    lista->sig->sig->sig = new Nodo<int>(2);

    Nodo<int>* aux = lista;
    while (aux != 0) {
        cout << aux->dato << " ";
        aux = aux->sig;
    }
    cout << endl;

    stack<int> pila;
    pila.push(10);
    pila.push(20);
    pila.push(30);

    while (!pila.empty()) {
        cout << pila.top() << " ";
        pila.pop();
    }
    cout << endl;

    delete[] arrInt;
    return 0;
}
